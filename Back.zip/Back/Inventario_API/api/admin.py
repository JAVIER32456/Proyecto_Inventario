from django.contrib import admin
from .models import Propietarios
from .models import vehiculos

# Register your models here.

admin.site.register(Propietarios)
admin.site.register(vehiculos)