from django.db import models

# Create your models here.
#Creamos las dos tablas que van a estar en la base de datos.

class Propietarios(models.Model):
    tipoDocumento = models.CharField(max_length=20)
    documento = models.IntegerField()
    nombre_apellidos = models.CharField(max_length=50)
    direccion = models.CharField(max_length=50)
    telefono = models.CharField(max_length=20)
    email = models.EmailField()

class vehiculos(models.Model):
    placa = models.PositiveBigIntegerField()
    marca = models.PositiveBigIntegerField()
    modelo = models.PositiveBigIntegerField()
    año = models.PositiveBigIntegerField()
    color = models.CharField(max_length=20)
    propietarios = models.ForeignKey(Propietarios, on_delete=models.CASCADE)
    observaciones = models.CharField(max_length=250)
    fecha_registro = models.PositiveBigIntegerField()