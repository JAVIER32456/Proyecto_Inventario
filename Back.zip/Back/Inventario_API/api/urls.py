
#Creamos una vista para poder realizar las peticiones
from django.urls import path
from .views import vistas

urlpatterns=[
    path('inventario/', vistas.as_view(), name='inventario_list'),
    path('inventario/<int:id>', vistas.as_view(), name='inventario_procesos')
]
