
from django.http.response import JsonResponse
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt
from django.views import View
from .models import Propietarios
import json

# Create your views here.
# Aca creamos las CRUD para hacer peticiones a la base de datos(CLIENTE-SERVIDOR) 
# Tambien trabajamos con el ORM 

class vistas(View):

    @method_decorator(csrf_exempt)
    def dispatch(self, request, *args, **kwargs):
        return super().dispatch(request, *args, **kwargs)

    def get(self, request, id=0):
        if ( id>0):
            inventario=list(Propietarios.objects.filter(id=id).values())
            if len(inventario) > 0:
                Propieta = inventario[0]
                datos={'message':"Exito...",'inventario':Propieta}
            else:
                datos={'message':"Pagina no encontrada"}
            return JsonResponse(datos)
        else:
            inventario=list(Propietarios.objects.values())
            if len(inventario)>0:
                datos={'message':"Exito...",'inventario':inventario}
            else:
                datos={'message':"Pagina no encontrada"}
            return JsonResponse(datos)


    def post(self, request):
       # print(request.body)
        jd=json.loads(request.body)
        # print(jd)
        Propietarios.objects.create(tipoDocumento=jd['tipoDocumento'],documento=jd['documento'],nombre_apellidos=jd['nombre_apellidos'],direccion=jd['direccion'],telefono=jd['telefono'],email=jd['email'])
        datos = {'message': "Exito.."}
        return JsonResponse(datos)


    def put(self, request,id):
        jd = json.loads(request.body)
        inventario=list(Propietarios.objects.filter(id=id).values())
        if len(inventario) > 0:
            Propieta = Propietarios.objects.get(id=id)
            Propieta.tipoDocumento = jd['tipoDocumento']
            Propieta.documento = jd['documento']
            Propieta.nombre_apellidos = jd['nombre_apellidos']
            Propieta.direccion = jd['direccion']
            Propieta.telefono = jd['telefono']
            Propieta.email = jd['email']
            Propieta.save()
            datos = {'message': "Exito.."}
        else:
            datos={'message':"Pagina no encontrada"}
        return JsonResponse(datos)
        



    def delete(self, request,id):
        inventario=list(Propietarios.objects.filter(id=id).values())
        if len(inventario) > 0:
            Propietarios.objects.filter(id=id).delete()
            datos = {'message': "Exito.."}
        else:
            datos={'message':"Pagina no encontrada"}
        return JsonResponse(datos)